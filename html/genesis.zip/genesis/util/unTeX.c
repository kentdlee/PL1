/* File unTeX.c created by Kent Lee on Wed Jul  5 1995*/
#include <stdio.h>

int main (int argc, char *argv[])
{
  int s, c, toggle, newFunc, equation;
  char behind[100];
  
  s=0;
  toggle=0;
  newFunc=0;
  equation=1;
  
  
  while ((c=getchar()) != EOF ) {
    /* printf("state = %d\n",s); */
    switch (s) {
    case 0:
      if (c=='\\') s=1;
      else if (c=='$') s=0;
      else if (c=='&') s=0;
      else if (c=='{') s=0;
      else if (c=='}') s=0;
      else if (toggle==1) putchar(c);
      break;
    case 1: /* subsection, item, or end */
      if (c=='s') s=2;
      else if (c=='i') s=10;
      else if (c=='I') {
	s=10;
	newFunc=1;
      }
      else if (c=='e') s=13;
      else if (c=='b') s=17;
      else if (c=='t') s=26;
      else if (c=='<') {
	if (toggle==1)
	  printf(" (");
	s=0;
      }
      else if (c=='>') {
	if (toggle==1)
	  printf(")");
	s=0;
      }
      else if (c=='(') {
	if (toggle==1)
	  printf("  ");
	s=0;
      }
      else if (c==')') s=0;
      else if (c=='=') s=0;
      else if (c=='\\') s=0;
      else if (((c>='a')&&(c<='z'))||
	       ((c>='A')&&(c<='Z'))) s=15;
      else if (toggle==1) {
	putchar(c);
	s=0;
      }
      else s=0;
      break;
    case 2: /* subsection */
      if (c=='u') s=39;
      else if (c=='i') s=16;
      else s=15;
      break;
    case 39: 
      if (c=='b') s=40; else s=15;
      break;
    case 40: 
      if (c=='s') s=41; else s=15;
      break;
    case 41: 
      if (c=='e') s=3; else s=15;
      break;
    case 3:
      if (c=='c') s=4; else s=15;
      break;
    case 4:
      if (c=='t') s=5; else s=15;
      break;
    case 5:
      if (c=='i') s=6; else s=15;
      break;
    case 6:
      if (c=='o') s=7; else s=15;
      break;
    case 7:
      if (c=='n') s=8; else s=15;
      break;
    case 8:
      if (c=='{') {
	s=9;
	printf("begin ");
      }
      else s=15;
      break;
    case 9:
      if (c=='}') {putchar('\n'); s=0;}
      else putchar(c);
      break;
    case 10: /* item */
      if (c=='t') s=11;
      else if (c=='n') s=33;
      else s=15;
      break;
    case 11:
      if (c=='e') s=12; else s=15;
      break;
    case 12:
      if (c=='m') {
	s=31;
	if (newFunc) {
	  printf("\n@ ");
	  newFunc=0;
	} else 
	  printf("\n(%d) ",equation++);
	toggle=1;
      } else s=15;
      break;
    case 13: /* end */
      if (c=='n') s=14; else s=15;
      break;
    case 14:
      if (c=='d') {
	s=0;
	if (toggle==1) {
	  printf("\nend\n\n");
	  equation=1;
	}
	toggle=0;
      }
      else s=15;
      break;
    case 15: /* catch all for throwing away */
      if ((c==' ')||(c=='\n')||(c=='\t')) s=0;
      break;
    case 16:
      if (c=='m') {
	if (toggle==1) {
	  putchar('~');
	}
	s=0;
      }
      else s=15;
      break;
    case 17:
      if (c=='a') s=18;
      else if (c=='u') s=35;
      else s=15;
      break;
    case 18:
      if (c=='c') s=19; else s=15;
      break;
    case 19:
      if (c=='k') s=20; else s=15;
      break;
    case 20:
      if (c=='s') s=21; else s=15;
      break;
    case 21:
      if (c=='l') s=22; else s=15;
      break;
    case 22:
      if (c=='a') s=23; else s=15;
      break;
    case 23:
      if (c=='s') s=24; else s=15;
      break;
    case 24:
      if (c=='h') {
	if (toggle==1) putchar('\\');
	s=0;
      }
      else s=15;
      break;
    case 25: /* catch all for throwing away line */
      if (c=='\n') s=0;
      break;
    case 26:
      if (c=='a') s=27; else s=15;
      break;
    case 27:
      if (c=='b') s=28; else s=15;
      break;
    case 28:
      if (c=='s') s=29;
      else if (c==' ') s=0;
      else s=15;
      break;
    case 29:
      if (c=='e') s=30; else s=15;
      break;
    case 30:
      if (c=='t') s=25; else s=15;
      break;
    case 31:
      if (c=='[') s=32; else s=0;
      break;
    case 32:
      s=0;
      break;
    case 33:
      if (c=='t') s=34; else s=0;
      break;
    case 34:
      if (c=='o') {
	if (toggle==1) printf("->");
	s=0;
      }
      else s=15;
      break;
    case 35: /* change bullets to periods */
      if (c=='l') s=36; else s=15;
      break;
    case 36:
      if (c=='l') s=37; else s=15;
      break;
    case 37:
      if (c=='e') s=38; else s=15;
      break;
    case 38:
      if (c=='t') {
	if (toggle==1) putchar('.');
	s=0;
      }
      else s=15;
      break;
    }
  }
  
  return 0;
}
